import json
import csv

def csv_yaz(toplam, en_urun, musteriler, ilk3):
    with open("results.csv", "w", newline="", encoding="utf-8") as f:
        yazici = csv.writer(f)

        yazici.writerow(["Toplam Ciro", round(toplam, 2)])
        yazici.writerow([])

        yazici.writerow(["En Cok Gelir Getiren Urun", en_urun[0], round(en_urun[1], 2)])
        yazici.writerow([])

        yazici.writerow(["Musteri", "Toplam Harcama"])
        for m, h in musteriler.items():
            yazici.writerow([m, round(h, 2)])

        yazici.writerow([])
        yazici.writerow(["En Cok Harcama Yapan Ilk 3 Musteri"])
        for m, h in ilk3:
            yazici.writerow([m, round(h, 2)])

def dosya_oku():
    with open("orders.json", "r", encoding="utf-8") as f:
        return json.load(f)


def toplam_ciro(siparisler):
    toplam = 0

    for siparis in siparisler:
        tutar = siparis["unit_price"] * siparis["quantity"]

        indirim = tutar * siparis["discount_rate"] / 100

        toplam += tutar - indirim + siparis["shipping_fee"]

    return toplam


def en_cok_gelir_getiren_urun(siparisler):
    urunler = {}

    for siparis in siparisler:
        urun = siparis["product_name"]

        gelir = siparis["unit_price"] * siparis["quantity"]
        gelir = gelir - gelir * siparis["discount_rate"] / 100

        if urun in urunler:
            urunler[urun] += gelir
        else:
            urunler[urun] = gelir

    en_iyi = max(urunler, key=urunler.get)

    return en_iyi, urunler[en_iyi]


def musteri_harcamalari(siparisler):
    musteriler = {}

    for siparis in siparisler:
        musteri = siparis["customer_name"]

        harcama = siparis["unit_price"] * siparis["quantity"]
        harcama = harcama - harcama * siparis["discount_rate"] / 100
        harcama += siparis["shipping_fee"]

        if musteri in musteriler:
            musteriler[musteri] += harcama
        else:
            musteriler[musteri] = harcama

    return musteriler


def ilk_uc(musteriler):
    sirali = sorted(musteriler.items(), key=lambda x: x[1], reverse=True)
    return sirali[:3]


siparisler = dosya_oku()

print("Toplam Ciro:")
print(toplam_ciro(siparisler))

print("\nEn Cok Gelir Getiren Urun:")
print(en_cok_gelir_getiren_urun(siparisler))

musteriler = musteri_harcamalari(siparisler)

print("\nMusteri Harcamalari:")
for m, h in musteriler.items():
    print(m, ":", round(h, 2))

print("\nEn Cok Harcama Yapan Ilk 3 Musteri:")
for m, h in ilk_uc(musteriler):
    print(m, ":", round(h, 2))

csv_yaz(
    toplam_ciro(siparisler),
    en_cok_gelir_getiren_urun(siparisler),
    musteriler,
    ilk_uc(musteriler)
)    